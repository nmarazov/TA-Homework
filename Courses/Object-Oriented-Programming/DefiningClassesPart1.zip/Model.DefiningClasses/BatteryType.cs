﻿namespace Model.DefiningClasses
{
    public enum BatteryType
    {
        Li_Ion,
        NiMH,
        NiCd,
        Li_Po
    }
}
