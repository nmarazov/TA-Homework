﻿namespace School.Common
{
    public static class GlobalConstants
    {
        public const int MaxStudentsInCourse = 30;
        public const int MaxStudents = 2000;
        public const int StudentIdStartsFrom = 0;
    }
}
