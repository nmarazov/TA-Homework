﻿namespace VersionAttribute
{
    using System;
    using System.Collections.Generic;

    public class VersionAttribute
    {
    }
}
