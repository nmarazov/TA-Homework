﻿namespace VersionAttribute
{
    using System;
    using System.Collections.Generic;

    class VersionAttribute
    {

    }
}
